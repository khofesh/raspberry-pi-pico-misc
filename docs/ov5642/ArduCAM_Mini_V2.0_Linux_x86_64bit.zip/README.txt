/**************************************************************************/
2017/06/09  V2.1.0  by Lee	Add support for 4 cameras and camera functions.

This software is used for linux.

This is the new version and it can support 4 cameras work at the same time.

Before using it,you should run below command:

*************************************************************************** /

  Step1: Open the terminal and enter the folder of the software

  Step2: Input��sudo chmod +x run.sh
           
  Step3: Input��sudo ./run.sh
			         
  Step4: Input��sudo chmod u+x ArduCAM_Mini_QT��name of software��
 
  Step5: Inout��sudo chmod u+x ArduCAM_Mini_QT.sh
       
  Step6: Inout��sudo ./ArduCAM_Mini_QT.sh     


ln -s $PWD/libQt5Core.so.5.7.0 libQt5Core.so.5
ln -s $PWD/libQt5Widgets.so.5.7.0 libQt5Widgets.so.5
ln -s $PWD/libQt5Gui.so.5.7.0 libQt5Gui.so.5
ln -s $PWD/libQt5Network.so.5.7.0 libQt5Network.so.5
ln -s $PWD/libQt5SerialPort.so.5.7.0 libQt5SerialPort.so.5
ln -s $PWD/libicudata.so.56.1 libicudata.so.56
ln -s $PWD/libicui18n.so.56.1 libicui18n.so.56
ln -s $PWD/libicuuc.so.56.1 libicuuc.so.56
ln -s $PWD/libQt5XcbQpa.so.5.7.0 libQt5XcbQpa.so.5
ln -s $PWD/libQt5DBus.so.5.7.0 libQt5DBus.so.5


export set LD_LIBRARY_PATH=$PWD:$LD_LIBRARY_PATH

